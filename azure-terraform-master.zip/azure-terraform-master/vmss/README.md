# README

> Revised for _Terraform AzureRM v2.30_

Sample terraform script for VMM.

For large application deployment, it is recommend to deploy VMSS instead of creating multiple VMs.
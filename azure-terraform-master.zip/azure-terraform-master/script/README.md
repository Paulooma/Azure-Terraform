# Cloud-Init

__cloud-init__ is used instead of __custom script__ VM Extension for this demo.

See [document](https://cloudinit.readthedocs.io/en/latest/) for more information.

